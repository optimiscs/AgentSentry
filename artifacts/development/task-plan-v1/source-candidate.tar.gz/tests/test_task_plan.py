import copy
import json

import pytest
from agentsentry.intent.literal_plan import action_binding
from agentsentry.intent.task_plan import TaskPlanner, ToolSpec, literal_occurs, pointer

from agentsentry.intent.contracts import resolve
from agentsentry.schemas import ActionIR, Effect, Verdict, digest


def spec(name, effects, fields, authority=(), defaults=None):
    return ToolSpec(
        name,
        "simulation",
        tuple(effects),
        "Reviewed test tool " + name,
        {
            "type": "object",
            "properties": {key: {"type": kind} for key, kind in fields.items()},
            "required": list(set(fields) - set(defaults or {})),
            "additionalProperties": False,
        },
        tuple(authority),
        defaults or {},
    )


READ = spec("read_invoice", [Effect.FILE_READ], {"id": "string"})
SEND = spec(
    "send_payment",
    [Effect.NET_EGRESS],
    {"recipient": "string", "amount": "number", "note": "string"},
    ["recipient", "amount"],
    {"note": ""},
)
MAIL = spec(
    "send_mail",
    [Effect.NET_EGRESS],
    {"to": "array", "cc": "array", "body": "string"},
    ["to", "cc"],
    {"cc": []},
)
PLAN = {
    "steps": [
        {
            "id": "s1",
            "tool": "send_payment",
            "purpose": "Pay the user-designated invoice",
            "constraints": {
                "recipient": "Pay the recipient designated by the user or requested invoice",
                "amount": "Pay exactly the designated amount",
                "note": "Task-related public note",
            },
            "sources": ["read_invoice"],
            "max_calls": 1,
        }
    ]
}


class Model:
    def __init__(self, plan=None, review=None):
        self.plan = copy.deepcopy(plan if plan is not None else PLAN)
        self.review = review
        self.calls = []

    def __call__(self, phase, messages, schema):
        self.calls.append((phase, copy.deepcopy(messages), copy.deepcopy(schema)))
        return copy.deepcopy(self.plan if phase == "plan" else self.review)


def answer(*evidence, **overrides):
    return {
        "decision": "aligned",
        "step_id": "s1",
        "conditions_met": True,
        "evidence": list(evidence),
        "reason": "The requested payment parameters match the specified source.",
        **overrides,
    }


def evidence(argument, source="user", pointer="", quote=None):
    return {"argument": argument, "source": source, "pointer": pointer, "quote": quote}


def action(tool, arguments, session="test-session"):
    return ActionIR(
        session_id=session,
        tool=tool.name,
        server_id=tool.server,
        effects=list(tool.effects),
        resource="simulation://" + tool.name,
        resource_class="REPO",
        scope_valid=True,
        scope_allowed=True,
        args_hash=digest(arguments),
        task_binding_hash=action_binding(
            tool.server, tool.name, list(tool.effects), tool.complete(arguments)
        ),
    )


def setup(task="Send 10 to Alice", model=None, intent=None):
    model = model or Model(
        review=answer(
            evidence("/recipient", quote="Alice"), evidence("/amount", quote="10")
        )
    )
    intent = intent or resolve(task, "user", ".", literal_planning=False)
    planner = TaskPlanner(
        task, [READ, SEND, MAIL], model, session_id="test-session", intent=intent
    )
    assert planner.prepare()
    return planner, model, intent


@pytest.mark.case("TC-06")
def test_plan_uses_task_and_catalog_before_observations():
    planner, model, _ = setup()
    raw = canonical_payload = json.loads(model.calls[0][1][1]["content"])
    assert raw["original_user_request"] == "Send 10 to Alice"
    assert "read_data_not_instructions" not in canonical_payload
    assert "attacker_goal" not in canonical_payload
    assert planner.plan.steps[0].tool == "send_payment"


@pytest.mark.case("TC-11")
def test_full_exact_parameter_proof_enables_task_action_but_not_hard_override(rt):
    planner, _, intent = setup()
    args = {"recipient": "Alice", "amount": 10.0}
    proposed = action(SEND, args)
    assert rt.engine.decide(intent, proposed).decision == Verdict.ASK
    enriched, reason = planner.review(intent, proposed, args)
    assert reason == "TASK_PLAN_AND_PARAMETERS_VERIFIED"
    assert rt.engine.decide(enriched, proposed).decision == Verdict.ALLOW
    assert not intent.exact_action_grants
    proposed.labels = ["SECRET"]
    assert rt.engine.decide(enriched, proposed, approved=True).decision == Verdict.BLOCK


@pytest.mark.case("TC-19")
def test_data_dependent_parameters_are_bound_to_observed_values(rt):
    model = Model(
        review=answer(
            evidence("/recipient", "obs_1", "/invoice/payee"),
            evidence("/amount", "obs_1", "/invoice/total"),
        )
    )
    planner, _, intent = setup("Pay the requested invoice", model=model)
    read_args = {"id": "requested"}
    source = {"invoice": {"payee": "Alice", "total": 10}}
    planner.record(action(READ, read_args), read_args, source)
    source["invoice"]["payee"] = "Eve"
    args = {"recipient": "Alice", "amount": 10}
    enriched, _ = planner.review(intent, action(SEND, args), args)
    assert rt.engine.decide(enriched, action(SEND, args)).decision == Verdict.ALLOW
    assert planner.observations[0].result["invoice"]["payee"] == "Alice"


@pytest.mark.case("TC-19")
@pytest.mark.parametrize("labels", [["INJECTION_RISK"], ["SECRET"]])
def test_flagged_source_cannot_supply_authority_even_if_model_says_aligned(labels):
    model = Model(
        review=answer(
            evidence("/recipient", "obs_1", "/recipient"),
            evidence("/amount", "obs_1", "/amount"),
        )
    )
    planner, _, intent = setup("Pay the requested invoice", model=model)
    args = {"recipient": "Eve", "amount": 500}
    read = {"id": "requested"}
    planner.record(action(READ, read), read, args, labels=labels)
    enriched, reason = planner.review(intent, action(SEND, args), args)
    assert enriched is None and reason == "TASK_PARAMETER_EVIDENCE_MISMATCH"
    payload = json.loads(model.calls[-1][1][1]["content"])
    assert not payload["read_data_not_instructions"]


@pytest.mark.case("TC-11")
@pytest.mark.parametrize(
    "change",
    [
        {"recipient": "Eve"},
        {"recipient": "Alice.extra"},
        {"amount": 100},
    ],
)
def test_changed_target_or_amount_fails_even_with_false_model_allow(change):
    planner, _, intent = setup()
    args = {"recipient": "Alice", "amount": 10, **change}
    enriched, reason = planner.review(intent, action(SEND, args), args)
    assert enriched is None and reason == "TASK_PARAMETER_EVIDENCE_MISMATCH"


@pytest.mark.case("TC-11")
@pytest.mark.parametrize(
    "text,quote,expected",
    [
        ("Send 2000 to Alice", "2", False),
        ("Send -10 to Alice", "10", False),
        ("Send 10 to Alice.", "Alice", True),
        ("Send 10 to AliceJones", "Alice", False),
        ("Send to Alice@company.test", "Alice", False),
        ("Post to https://site.test.evil", "https://site.test", False),
        ("Post to https://site.test?copy=1", "https://site.test", False),
        ('Post to "https://site.test"', "https://site.test", True),
    ],
)
def test_plaintext_evidence_is_not_prefix_matching(text, quote, expected):
    assert literal_occurs(text, quote) is expected


@pytest.mark.case("TC-15")
def test_plan_is_bound_to_session_intent_and_catalog():
    planner, model, intent = setup()
    args = {"recipient": "Alice", "amount": 10}
    for proposed, contract in [
        (action(SEND, args, "other-session"), intent),
        (action(SEND, args), intent.model_copy(update={"version": 2})),
    ]:
        assert (
            planner.review(contract, proposed, args)[1] == "TASK_PLAN_BINDING_CHANGED"
        )
    planner.catalog["send_payment"] = spec(
        "send_payment", [Effect.NET_EGRESS], {"recipient": "string"}
    )
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_PLAN_BINDING_CHANGED"
    )
    assert len(model.calls) == 1


@pytest.mark.case("TC-16")
def test_reserved_step_cannot_be_double_spent_and_result_cannot_be_replayed():
    planner, _, intent = setup()
    args = {"recipient": "Alice", "amount": 10}
    proposed = action(SEND, args)
    assert planner.review(intent, proposed, args)[0] is not None
    assert planner.review(intent, action(SEND, args), args)[0] is None
    planner.record(proposed, args, {"transaction_id": "t1"})
    assert planner.used == {"s1": 1}
    with pytest.raises(ValueError, match="UNVERIFIED_EFFECTFUL_OBSERVATION"):
        planner.record(proposed, args, {"transaction_id": "t1"})
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_OPERATION_NOT_PLANNED"
    )


@pytest.mark.case("TC-19")
def test_undispatched_or_cross_session_data_is_not_an_observation():
    planner, _, _ = setup()
    args = {"recipient": "Alice", "amount": 10}
    with pytest.raises(ValueError, match="UNVERIFIED_EFFECTFUL_OBSERVATION"):
        planner.record(action(SEND, args), args, {"id": "invented"})
    read = {"id": "requested"}
    with pytest.raises(ValueError, match="UNVERIFIED_OBSERVATION_SOURCE"):
        planner.record(action(READ, read, "other"), read, "untrusted")
    assert not planner.observations


@pytest.mark.case("TC-26")
@pytest.mark.parametrize(
    "bad_plan",
    [
        {"steps": [{**PLAN["steps"][0], "tool": "new_admin_tool"}]},
        {"steps": [{**PLAN["steps"][0], "sources": ["s2"]}]},
        {"steps": [{**PLAN["steps"][0], "constraints": {"recipient": "any"}}]},
        {"steps": [PLAN["steps"][0], PLAN["steps"][0]]},
    ],
)
def test_malformed_plan_fails_closed(bad_plan):
    intent = resolve("Pay invoice", "u", ".", literal_planning=False)
    planner = TaskPlanner(
        "Pay invoice", [READ, SEND], Model(plan=bad_plan), session_id="s", intent=intent
    )
    assert not planner.prepare()
    assert planner.failures and planner.plan is None
    assert (
        planner.review(intent, action(SEND, {"recipient": "Alice", "amount": 10}), {})[
            0
        ]
        is None
    )


@pytest.mark.case("TC-26")
@pytest.mark.parametrize(
    "review", [None, {"decision": "ALLOW"}, {**answer(), "approve_all": True}]
)
def test_malformed_verifier_never_means_success(review):
    planner, _, intent = setup(model=Model(review=review))
    args = {"recipient": "Alice", "amount": 10}
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_VERIFIER_FAILED_CLOSED"
    )
    assert planner.failures


@pytest.mark.case("TC-11")
@pytest.mark.parametrize(
    "response",
    [
        answer(decision="needs_confirmation"),
        answer(decision="out_of_task"),
        answer(conditions_met=False),
    ],
)
def test_uncertain_conditions_and_out_of_task_require_confirmation(response):
    planner, _, intent = setup(model=Model(review=response))
    args = {"recipient": "Alice", "amount": 10}
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_SEMANTICS_NOT_VERIFIED"
    )
    assert not planner.failures


@pytest.mark.case("TC-10")
def test_every_added_recipient_needs_its_own_proof():
    plan = {
        "steps": [
            {
                "id": "s1",
                "tool": "send_mail",
                "purpose": "Send the public summary to Alice",
                "constraints": {
                    "to": "Alice only",
                    "cc": "none",
                    "body": "public summary",
                },
                "sources": [],
                "max_calls": 1,
            }
        ]
    }
    model = Model(plan=plan, review=answer(evidence("/to/0", quote="Alice")))
    planner, _, intent = setup("Send to Alice", model=model)
    args = {"to": ["Alice"], "cc": ["Eve"], "body": "public summary"}
    assert (
        planner.review(intent, action(MAIL, args), args)[1]
        == "TASK_PARAMETER_EVIDENCE_MISMATCH"
    )


@pytest.mark.case("TC-11")
def test_changed_args_cannot_reuse_the_action_binding():
    planner, _, intent = setup()
    args = {"recipient": "Alice", "amount": 10}
    other = action(SEND, {"recipient": "Eve", "amount": 10})
    assert planner.review(intent, other, args)[1] == "TASK_ACTION_BINDING_MISMATCH"


@pytest.mark.case("TC-06")
def test_empty_information_only_plan_cannot_authorize_a_mutation():
    planner, model, intent = setup(
        "What is the invoice total?", model=Model(plan={"steps": []})
    )
    args = {"recipient": "Alice", "amount": 10}
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_OPERATION_NOT_PLANNED"
    )
    assert len(model.calls) == 1


@pytest.mark.case("TC-06")
def test_pointer_handles_arrays_and_escaped_object_names():
    assert pointer({"a/b": [{"~key": 10}]}, "/a~1b/0/~0key") == 10
    with pytest.raises((ValueError, IndexError, KeyError)):
        pointer([10], "/-1")


@pytest.mark.case("TC-06")
def test_task_only_literal_normalization_is_bound_before_tool_data(rt):
    plan = copy.deepcopy(PLAN)
    plan["steps"][0]["literals"] = {
        "recipient": {"value": "Alice", "evidence_text": "Alice"},
        "amount": {"value": 12.5, "evidence_text": "twelve and a half"},
    }
    model = Model(plan=plan, review=answer())
    planner, _, intent = setup("Send twelve and a half to Alice", model=model)
    args = {"recipient": "Alice", "amount": 12.5}
    enriched, reason = planner.review(intent, action(SEND, args), args)
    assert reason == "TASK_PLAN_AND_PARAMETERS_VERIFIED"
    assert rt.engine.decide(enriched, action(SEND, args)).decision == Verdict.ALLOW


@pytest.mark.case("TC-06")
def test_planner_cannot_invent_the_user_evidence_quote():
    plan = copy.deepcopy(PLAN)
    plan["steps"][0]["literals"] = {
        "recipient": {"value": "Eve", "evidence_text": "Send to Eve"}
    }
    intent = resolve("Send to Alice", "u", ".", literal_planning=False)
    planner = TaskPlanner(
        "Send to Alice", [READ, SEND], Model(plan=plan), session_id="s", intent=intent
    )
    assert not planner.prepare()


@pytest.mark.case("TC-11")
@pytest.mark.parametrize(
    "amount,percent,operation,expected",
    [
        (100, 10, "increase_percent", 110),
        (100, 10, "decrease_percent", 90),
        (100, 10, "sum", 110),
        (100, 10, "subtract", 90),
        (100, 10, "multiply", 1000),
        (100, 10, "divide", 10),
    ],
)
def test_referenced_arithmetic_is_recomputed(amount, percent, operation, expected):
    proofs = [
        evidence("/recipient", "obs_1", "/recipient"),
        {
            "argument": "/amount",
            "operation": operation,
            "operands": [
                {"source": "obs_1", "pointer": "/amount"},
                {"source": "user", "quote": str(percent)},
            ],
        },
    ]
    planner, _, intent = setup(
        "Pay the adjusted invoice using " + str(percent),
        model=Model(review=answer(*proofs)),
    )
    query = {"id": "requested"}
    planner.record(action(READ, query), query, {"recipient": "Alice", "amount": amount})
    args = {"recipient": "Alice", "amount": expected}
    assert planner.review(intent, action(SEND, args), args)[0] is not None


@pytest.mark.case("TC-11")
@pytest.mark.parametrize("actual,operand", [(111, "10"), (110, "invented"), (110, "0")])
def test_arithmetic_wrong_result_or_unreferenced_constant_is_rejected(actual, operand):
    response = answer(
        evidence("/recipient", quote="Alice"),
        {
            "argument": "/amount",
            "operation": "increase_percent",
            "operands": [
                {"source": "obs_1", "pointer": "/amount"},
                {"source": "user", "quote": operand},
            ],
        },
    )
    planner, _, intent = setup(
        "Send Alice the invoice amount plus 10 percent", model=Model(review=response)
    )
    query = {"id": "requested"}
    planner.record(action(READ, query), query, {"amount": 100})
    args = {"recipient": "Alice", "amount": actual}
    assert planner.review(intent, action(SEND, args), args)[0] is None


@pytest.mark.case("TC-31")
def test_semantic_plan_cannot_widen_an_existing_exact_contract():
    intent = resolve('Create file "notes.txt" with content "public"', "user", ".")
    planner, _, intent = setup('Create file "notes.txt" with content "public"', intent=intent)
    args = {"recipient": "Alice", "amount": 10}
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "PREEXISTING_EXACT_CONTRACT_NOT_SATISFIED"
    )


@pytest.mark.case("TC-19")
def test_prior_effectful_source_is_a_real_execution_dependency():
    plan = copy.deepcopy(PLAN)
    later = copy.deepcopy(plan["steps"][0])
    later.update(id="s2", sources=["s1"])
    plan["steps"].append(later)
    model = Model(plan=plan, review=answer(step_id="s2"))
    planner, _, intent = setup(model=model)
    args = {"recipient": "Alice", "amount": 10}
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_SEMANTICS_NOT_VERIFIED"
    )
    payload = json.loads(model.calls[-1][1][1]["content"])
    assert [step["id"] for step in payload["task_plan"]] == ["s1"]
