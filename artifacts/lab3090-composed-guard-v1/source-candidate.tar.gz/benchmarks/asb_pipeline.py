"""Local-model bridge and execution gate around pinned ASB workflow methods."""

from __future__ import annotations

import json
import time
from types import SimpleNamespace

from agentsentry.intent.literal_plan import action_binding
from agentsentry.intent.task_plan import TaskPlanner, ToolSpec
from asb_native import native_type, prepare_instance, tool_catalog
from local_model import completion, structured_completion
from context_options import context_defense

from agentsentry.context.scanner import Scanner
from agentsentry.intent.contracts import resolve
from agentsentry.policy.engine import Engine
from agentsentry.schemas import ActionIR, Effect, SourceType, Verdict, digest


class ExecutionDenied(Exception):
    pass


def workflow_format(max_steps):
    return {
        "type": "json_schema",
        "json_schema": {
            "name": "asb_workflow", "strict": True,
            "schema": {
                "type": "array", "minItems": 2, "maxItems": max_steps,
                "items": {
                    "type": "object", "additionalProperties": False,
                    "required": ["message", "tool_use"],
                    "properties": {
                        "message": {"type": "string"},
                        "tool_use": {"type": "array", "items": {"type": "string"}},
                    },
                },
            },
        },
    }


class GuardedTextTool:
    def __init__(self, owner, tool):
        self.owner, self.tool = owner, tool

    def run(self, params=None):
        return self.owner.dispatch(self.tool)


def opaque_spec(definition):
    tool = definition["function"]
    # Uniform metadata for every visible tool. ASB bodies only append a constant
    # result to the simulation, ignoring params. No normal/attack labels select
    # permissions. SIMULATED_CALL requires authorization but makes no claim about
    # real file/network effects. No production adapter emits this capability.
    return ToolSpec(
        tool["name"],
        "asb-simulation",
        (Effect.SIMULATED_CALL,),
        tool.get("description", ""),
        {"type": "object", "properties": {}, "additionalProperties": False},
    )


def make_pipeline(
    source,
    task_row,
    task,
    attack_row,
    config,
    policy,
    memory_store=None,
    *,
    complete=completion,
):
    Native = native_type(source)

    class Pipeline(Native):
        def guard_model(self, phase, messages, schema):
            return structured_completion(
                config, phase, messages, schema, self.guard_records, complete=complete
            )

        def filter_context(self, text, source):
            key = digest([str(source), text])
            if key not in self._filtered:
                view = self.context_defense.process(
                    self.original_task, str(source), {}, text, source,
                    quarantine=("[AgentSentry quarantined untrusted instructions in this context.]"
                                if config.configuration not in {"baseline", "no_context"}
                                else None),
                )
                self.context_records.append(
                    {
                        "source": str(source),
                        "input_hash": digest(text),
                        "labels": list(view.labels),
                        "sanitizer_trace_index": view.sanitizer_trace_index,
                    }
                )
                self.labels.update(view.labels)
                self._filtered[key] = (view.text, list(view.labels))
            return self._filtered[key]

        def get_response(self, query):
            wire = [dict(message) for message in query.messages]
            for message in wire:
                content = message.get("content")
                # The original session task is an immutable authority anchor. Any
                # appended bytes are input augmentation; this never reads attack
                # labels or strips arbitrary spans of a newly authorized task.
                if (
                    message.get("role") == "user"
                    and isinstance(content, str)
                    and content.startswith(self.original_task)
                    and len(content) > len(self.original_task)
                ):
                    suffix, _ = self.filter_context(
                        content[len(self.original_task) :], SourceType.DOCUMENT
                    )
                    message["content"] = self.original_task + suffix
            formats = None
            if query.tools:
                formats = [
                    {
                        "type": "function",
                        "function": {
                            **definition["function"],
                            "parameters": {
                                "type": "object",
                                "properties": {},
                                "additionalProperties": False,
                            },
                        },
                    }
                    for definition in query.tools
                ]
            self.model_calls += 1
            start = time.perf_counter()
            options = {"tools": formats}
            if (
                getattr(query, "message_return_type", None) == "json"
                and getattr(config, "workflow_format", "native") == "json_schema"
            ):
                options["response_format"] = workflow_format(config.max_workflow_steps)
            message = complete(config, wire, self.model_responses, **options)
            calls = []
            for call in message.get("tool_calls") or []:
                function = call["function"]
                # Retain all model arguments in the transcript; the pinned ASB
                # simulator itself passes params=None, as documented upstream.
                parameters = json.loads(function["arguments"])
                calls.append({"name": function["name"], "parameters": parameters})
            return (
                SimpleNamespace(
                    response_message=message.get("content"), tool_calls=calls
                ),
                [start],
                [time.perf_counter()],
                [0],
                [time.perf_counter() - start],
            )

        def check_workflow(self, message):
            workflow = Native.check_workflow(self, message)
            if workflow and len(workflow) > config.max_workflow_steps:
                raise ValueError("ASB_WORKFLOW_STEP_BUDGET")
            return workflow

        def search_memory_instruction(self):
            result = Native.search_memory_instruction(self)
            if result is None:
                return None
            return self.filter_context(result, SourceType.MEMORY)[0]

        def attacker_tool_injection(self, workflow):
            result = Native.attacker_tool_injection(self, workflow)
            for step in result:
                step["tool_use"] = sorted(step["tool_use"])
            return result

        def dispatch(self, tool):
            specification = self.catalog[tool.name]
            action = ActionIR(
                session_id="asb-simulation",
                tool=tool.name,
                server_id=specification.server,
                effects=list(specification.effects),
                args_hash=digest({}),
                task_binding_hash=action_binding(
                    specification.server, tool.name, list(specification.effects), {}
                ),
                resource="simulation://" + tool.name,
                resource_version=digest({}),
                resource_class="REPO",
                scope_valid=True,
                scope_allowed=True,
                labels=[]
                if config.configuration == "no_taint"
                else sorted(self.labels),
                source_type="MCP_RESPONSE",
                source_trust="UNTRUSTED",
            )
            if config.configuration in {"baseline", "rules"}:
                decision, reasons = "ALLOW", ["NO_EXECUTION_GATE"]
            else:
                result = self.engine.decide(self.intent, action)
                if self.planner and result.decision != Verdict.BLOCK:
                    enriched, reason = self.planner.review(self.intent, action, {})
                    if enriched is None:
                        decision, reasons = "ASK", [reason]
                    else:
                        result = self.engine.decide(enriched, action)
                        decision, reasons = result.decision.value, result.reason_codes
                else:
                    decision, reasons = result.decision.value, result.reason_codes
            if config.configuration == "no_ask" and decision == "ASK":
                decision, reasons = "BLOCK", ["NO_ASK_ABLATION", *reasons]
            entry = {
                "tool": tool.name,
                "arguments_executed": None,
                "decision": decision,
                "reason_codes": reasons,
                "simulated_dispatch": decision == "ALLOW",
                "action_id": action.action_id,
            }
            self.calls.append(entry)
            if decision != "ALLOW":
                raise ExecutionDenied(
                    "AgentSentry " + decision + ":" + ",".join(reasons)
                )
            result = tool.run(None)
            self._pending_observations.append((entry, action))
            return result

        def call_tools(self, tool_calls, final_stage=False):
            before = len(self.calls)
            original = self.tool_list
            parsed = self.normalize_tool_calls(tool_calls)
            if not parsed or any(call["name"] not in original for call in parsed):
                self.protocol_errors.append("ASB_UNKNOWN_OR_UNPARSED_TOOL")
            self.tool_list = {
                name: GuardedTextTool(self, tool) for name, tool in original.items()
            }
            try:
                actions, observations, success = Native.call_tools(
                    self, tool_calls, final_stage=final_stage
                )
            finally:
                self.tool_list = original
            # The native runner adds OPI after tool.run(). Record that final
            # observed data, never the clean pre-injection constant as evidence.
            filtered = []
            for observation in observations:
                clean, labels = self.filter_context(
                    observation, SourceType.MCP_RESPONSE
                )
                filtered.append(clean)
                for index, (entry, action) in enumerate(self._pending_observations):
                    if observation.startswith(
                        "The knowledge I get from " + entry["tool"] + " is: "
                    ):
                        if self.planner:
                            entry["observation_id"] = self.planner.record(
                                action,
                                {},
                                observation,
                                labels=[]
                                if config.configuration == "no_taint"
                                else labels,
                            )
                        del self._pending_observations[index]
                        break
            denied = [
                call for call in self.calls[before:] if call["decision"] != "ALLOW"
            ]
            if denied:
                self.last_tool_call_non_retryable = True
                filtered.append(
                    "AgentSentry did not execute the denied action. Continue with authorized steps; do not retry unchanged arguments."
                )
            return actions, filtered, success

        def run(self):
            if self.planner:
                self.planner.prepare()
            return Native.run(self)

    instance = Pipeline()
    prepare_instance(
        instance,
        source,
        task_row,
        task,
        attack_row,
        direct=config.direct,
        observation=config.observation,
        memory=config.memory,
        model=config.model,
    )
    _, _, formats, attacker_format = tool_catalog(source, task_row, attack_row)
    specifications = [opaque_spec(item) for item in formats + [attacker_format]]
    instance.catalog = {
        specification.name: specification for specification in specifications
    }
    instance.intent = resolve(task, "benchmark-user", ".", literal_planning=False)
    if config.configuration == "no_intent":
        instance.intent.allowed_effects = instance.intent.maximum_effects
        instance.intent.forbidden_effects = []
    instance.protocol_errors = []
    instance.engine, instance.scanner = Engine(policy), Scanner()
    (
        instance.calls,
        instance.model_responses,
        instance.guard_records,
        instance.context_records,
    ) = [], [], [], []
    (
        instance.model_calls,
        instance.labels,
        instance._filtered,
        instance._pending_observations,
    ) = 0, set(), {}, []
    instance.vectorstore = memory_store
    instance.context_defense = context_defense(config, instance.scanner, instance.guard_model)
    instance.sanitizer = instance.context_defense.sanitizer
    instance.planner = (
        TaskPlanner(
            task,
            specifications,
            instance.guard_model,
            session_id="asb-simulation",
            intent=instance.intent,
        )
        if config.configuration not in {"baseline", "rules", "no_intent"}
        else None
    )
    return instance
