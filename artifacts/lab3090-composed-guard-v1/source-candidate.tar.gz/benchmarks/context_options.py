"""Shared benchmark composition selection; every ablation keeps its meaning."""

from agentsentry.context.defense import ContextDefense
from agentsentry.context.sanitizer import ContextSanitizer


def context_defense(config, scanner, model):
    requested = getattr(config, "context_defense", "rules")
    if requested not in {"rules", "joint"}:
        raise ValueError("UNKNOWN_CONTEXT_DEFENSE")
    mode = None
    if config.configuration == "promptarmor_adapted":
        mode = getattr(config, "context_filter_mode", "two_stage")
    elif requested == "joint" and config.configuration not in {"baseline", "rules", "no_context"}:
        mode = "joint"
    return ContextDefense(scanner, ContextSanitizer(model, mode) if mode else None)
