"""Compose the actor's filtered view with monotone raw-source risk labels.

Filtering does not authenticate a source or authorize an action. The adapter
must retain the original observation for parameter evidence and audit.
"""

from dataclasses import dataclass

from .sanitizer import ContextSanitizer
from .scanner import Scanner


@dataclass(frozen=True)
class ContextView:
    text: str
    labels: tuple[str, ...]
    sanitizer_trace_index: int | None = None


class ContextDefense:
    def __init__(self, scanner: Scanner, sanitizer: ContextSanitizer | None = None):
        self.scanner, self.sanitizer = scanner, sanitizer

    def process(self, task, tool, arguments, text, source, *, quarantine=None,
                sanitize=True, semantic_taint=True):
        _, signal = self.scanner.scan("context-observation", text, source)
        labels, filtered, index = set(signal.labels), text, None
        if self.sanitizer is not None and sanitize:
            filtered = self.sanitizer.sanitize(task, tool, arguments, text)
            index = len(self.sanitizer.trace) - 1
            # A deletion is an additional risk finding, never declassification.
            # Legacy input-only references can retain their original label trace.
            if semantic_taint and self.sanitizer.trace[index]["spans"]:
                labels.add("INJECTION_RISK")
        elif quarantine is not None and "INJECTION_RISK" in labels:
            filtered = quarantine
        return ContextView(filtered, tuple(sorted(labels)), index)
