import copy
import json

import pytest
from jsonschema import ValidationError as SchemaError, validate
from agentsentry.intent.literal_plan import action_binding
from agentsentry.intent.task_plan import TaskPlanner, ToolSpec, literal_occurs, pointer

from agentsentry.intent.contracts import resolve
from agentsentry.schemas import ActionIR, Effect, Verdict, digest


def spec(name, effects, fields, authority=(), defaults=None):
    return ToolSpec(
        name,
        "simulation",
        tuple(effects),
        "Reviewed test tool " + name,
        {
            "type": "object",
            "properties": {key: {"type": kind} for key, kind in fields.items()},
            "required": list(set(fields) - set(defaults or {})),
            "additionalProperties": False,
        },
        tuple(authority),
        defaults or {},
    )


READ = spec("read_invoice", [Effect.FILE_READ], {"id": "string"})
SEND = spec(
    "send_payment",
    [Effect.NET_EGRESS],
    {"recipient": "string", "amount": "number", "note": "string"},
    ["recipient", "amount"],
    {"note": ""},
)
MAIL = spec(
    "send_mail",
    [Effect.NET_EGRESS],
    {"to": "array", "cc": "array", "body": "string"},
    ["to", "cc"],
    {"cc": []},
)
PLAN = {
    "steps": [
        {
            "id": "s1",
            "tool": "send_payment",
            "purpose": "Pay the user-designated invoice",
            "constraints": {
                "recipient": "Pay the recipient designated by the user or requested invoice",
                "amount": "Pay exactly the designated amount",
                "note": "Task-related public note",
            },
            "sources": ["read_invoice"],
            "max_calls": 1,
        }
    ]
}


class Model:
    def __init__(self, plan=None, review=None):
        self.plan = copy.deepcopy(plan if plan is not None else PLAN)
        self.review = review
        self.calls = []

    def __call__(self, phase, messages, schema):
        self.calls.append((phase, copy.deepcopy(messages), copy.deepcopy(schema)))
        return copy.deepcopy(self.plan if phase == "plan" else self.review)


def answer(*evidence, **overrides):
    return {
        "decision": "aligned",
        "step_id": "s1",
        "conditions_met": True,
        "evidence": list(evidence),
        "reason": "The requested payment parameters match the specified source.",
        **overrides,
    }


def evidence(argument, source="user", pointer="", quote=None):
    return {"argument": argument, "source": source, "pointer": pointer, "quote": quote}


def action(tool, arguments, session="test-session"):
    return ActionIR(
        session_id=session,
        tool=tool.name,
        server_id=tool.server,
        effects=list(tool.effects),
        resource="simulation://" + tool.name,
        resource_class="REPO",
        scope_valid=True,
        scope_allowed=True,
        args_hash=digest(arguments),
        task_binding_hash=action_binding(
            tool.server, tool.name, list(tool.effects), tool.complete(arguments)
        ),
    )


def setup(task="Send 10 to Alice", model=None, intent=None):
    model = model or Model(
        review=answer(
            evidence("/recipient", quote="Alice"), evidence("/amount", quote="10")
        )
    )
    intent = intent or resolve(task, "user", ".", literal_planning=False)
    planner = TaskPlanner(
        task, [READ, SEND, MAIL], model, session_id="test-session", intent=intent
    )
    assert planner.prepare()
    return planner, model, intent


@pytest.mark.case("TC-06")
def test_plan_uses_task_and_catalog_before_observations():
    planner, model, _ = setup()
    raw = canonical_payload = json.loads(model.calls[0][1][1]["content"])
    assert raw["original_user_request"] == "Send 10 to Alice"
    assert "read_data_not_instructions" not in canonical_payload
    assert "attacker_goal" not in canonical_payload
    assert planner.plan.steps[0].tool == "send_payment"


def test_generation_schema_uses_effects_without_authorizing_catalog_tools():
    planner, model, intent = setup()
    payload = json.loads(model.calls[0][1][1]["content"])
    metadata = {t["name"]: t for t in payload["reviewed_tools"]}
    assert not metadata[READ.name]["requires_authorization_step"]
    assert metadata[SEND.name]["requires_authorization_step"]
    schema = model.calls[0][2]
    assert set(schema["$defs"]["Step"]["properties"]["tool"]["enum"]) == {SEND.name, MAIL.name}
    # Catalog eligibility is not a grant: an unplanned tool is still denied.
    args = {"to": ["Alice"], "body": "Payment notice"}
    enriched, reason = planner.review(intent, action(MAIL, args), args)
    assert enriched is None and reason == "TASK_OPERATION_NOT_PLANNED"


@pytest.mark.parametrize("malformation", ["read_step", "array_constraint"])
def test_generator_and_backend_both_reject_unsupported_plan_structure(malformation):
    _, model, intent = setup()
    invalid = copy.deepcopy(PLAN)
    if malformation == "read_step":
        invalid["steps"][0].update(tool=READ.name, constraints={"id": "requested invoice"})
    else:
        invalid["steps"][0]["constraints"]["recipient"] = ["Alice"]
    with pytest.raises(SchemaError):
        validate(invalid, model.calls[0][2])
    planner = TaskPlanner("Send 10 to Alice", [READ, SEND, MAIL], Model(plan=invalid), session_id="test-session", intent=intent)
    assert not planner.prepare()
    assert planner.plan is None and planner.failures


def test_readonly_catalog_requires_empty_authorization_plan():
    task = "Read the designated invoice"
    model = Model(plan={"steps": []})
    planner = TaskPlanner(task, [READ], model, session_id="test-session", intent=resolve(task, "user", ".", literal_planning=False))
    assert planner.prepare()
    schema = model.calls[0][2]
    validate({"steps": []}, schema)
    assert schema["properties"]["steps"]["maxItems"] == 0
    assert planner.plan.steps == []


def test_proof_requirements_use_same_literals_and_defaults_as_final_check():
    plan = copy.deepcopy(PLAN)
    plan["steps"][0]["literals"] = {
        "recipient": {"value": "Alice", "evidence_text": "Alice"},
        "amount": {"value": 10, "evidence_text": "10"},
    }
    planner, model, intent = setup(model=Model(plan=plan, review=answer()))
    args = {"recipient": "Alice", "amount": 10}
    enriched, _ = planner.review(intent, action(SEND, args), args)
    assert enriched is not None
    _, messages, schema = model.calls[-1]
    requirements = json.loads(messages[1]["content"])["evidence_requirements"]
    assert requirements == {"s1": {"arguments": {}, "observation_ids": []}}
    validate(answer(), schema)
    with pytest.raises(SchemaError):
        validate(answer(evidence("/recipient", quote="Alice")), schema)


@pytest.mark.parametrize("change", [
    {"argument": "recipient"},
    {"source": "read_invoice"},
    {"source": "obs_missing"},
    {"source": "", "operands": [{"source": "user", "quote": "Alice"}]},
])
def test_malformed_value_proof_is_rejected_by_generation_and_final_checks(change):
    bad = answer(evidence("/recipient", quote="Alice"), evidence("/amount", quote="10"))
    bad["evidence"][0].update(change)
    planner, model, intent = setup(model=Model(review=bad))
    args = {"recipient": "Alice", "amount": 10}
    enriched, reason = planner.review(intent, action(SEND, args), args)
    assert enriched is None and reason == "TASK_PARAMETER_EVIDENCE_MISMATCH"
    schema = model.calls[-1][2]
    with pytest.raises(SchemaError):
        validate(bad, schema)


def test_proof_schema_preserves_valid_arithmetic_and_excludes_tainted_sources():
    task = "Send 2 plus 8 to Alice"
    review = answer(
        evidence("/recipient", quote="Alice"),
        {"argument": "/amount", "operation": "sum", "operands": [
            {"source": "user", "quote": "2"}, {"source": "user", "quote": "8"},
        ]},
    )
    planner, model, intent = setup(task=task, model=Model(review=review))
    read_args = {"id": "invoice-7"}
    planner.record(action(READ, read_args), read_args, {"recipient": "Alice", "amount": 10}, labels=["INJECTION_RISK"])
    args = {"recipient": "Alice", "amount": 10}
    enriched, _ = planner.review(intent, action(SEND, args), args)
    assert enriched is not None
    _, messages, schema = model.calls[-1]
    payload = json.loads(messages[1]["content"])
    assert payload["evidence_requirements"]["s1"]["observation_ids"] == []
    assert payload["read_data_not_instructions"] == []
    validate(review, schema)
    assert schema["$defs"]["SourceRef"]["properties"]["source"]["enum"] == ["user"]


def test_code_locates_exact_source_paths_and_numeric_spelling():
    planner, model, intent = setup(task="Pay the designated invoice")
    read_args = {"id": "invoice-7"}
    planner.record(action(READ, read_args), read_args,
                   {"a/b~c": [{"recipient": "Alice", "amount_text": "Total 10.00 dollars"}]})
    args = {"recipient": "Alice", "amount": 10}
    recipient = evidence("/recipient", "obs_1", "/a~1b~0c/0/recipient")
    amount = evidence("/amount", "obs_1", "/a~1b~0c/0/amount_text", "10.00")
    model.review = answer(recipient, amount)
    enriched, _ = planner.review(intent, action(SEND, args), args)
    assert enriched is not None
    payload = json.loads(model.calls[-1][1][1]["content"])
    options = payload["value_options"]["s1"]
    assert options["/recipient"] == [{**recipient, "operation": "value", "operands": []}]
    assert options["/amount"] == [{**amount, "operation": "value", "operands": []}]
    validate(model.review, model.calls[-1][2])


@pytest.mark.parametrize("value,expected", [("Alice", True), ("Alice.evil", False), ("Malice", False)])
def test_options_do_not_infer_a_recipient_from_partial_text(value, expected):
    planner, _, _ = setup(task="Pay invoice 7")
    args = {"id": "invoice-7"}
    planner.record(action(READ, args), args, {"text": "Recipient " + value})
    options = planner._value_options({"/recipient": "Alice"}, {o.id: o for o in planner.observations})
    assert bool(options["/recipient"]) is expected


@pytest.mark.parametrize("label", ["SECRET", "INJECTION_RISK"])
def test_source_options_respect_both_plan_sources_and_quarantine(label):
    planner, model, intent = setup(task="Pay invoice 7")
    args = {"id": "invoice-7"}
    planner.record(action(READ, args), args, {"recipient": "Alice", "amount": 10}, labels=[label])
    proposed = {"recipient": "Alice", "amount": 10}
    enriched, _ = planner.review(intent, action(SEND, proposed), proposed)
    assert enriched is None
    payload = json.loads(model.calls[-1][1][1]["content"])
    assert payload["value_options"]["s1"] == {"/recipient": [], "/amount": []}
    assert payload["read_data_not_instructions"] == []


def test_numeric_looking_recipient_cannot_be_justified_by_arithmetic():
    bad = answer({"argument": "/recipient", "operation": "sum", "operands": [
        {"source": "user", "quote": "1"}, {"source": "user", "quote": "2"},
    ]}, evidence("/amount", quote="10"))
    planner, model, intent = setup(task="Send 10 to account 3. Notes: 1 plus 2.", model=Model(review=bad))
    args = {"recipient": "3", "amount": 10}
    enriched, reason = planner.review(intent, action(SEND, args), args)
    assert enriched is None and reason == "TASK_PARAMETER_EVIDENCE_MISMATCH"
    with pytest.raises(SchemaError):
        validate(bad, model.calls[-1][2])


def test_model_can_decline_when_no_source_option_exists():
    plan = {"steps": [{"id": "s1", "tool": MAIL.name, "purpose": "Send requested note",
                       "constraints": {"to": "the designated account", "body": "requested note"},
                       "sources": []}]}
    model = Model(plan=plan, review=answer(decision="needs_confirmation", conditions_met=False))
    planner, model, intent = setup(task="Send a note to the designated account", model=model)
    args = {"to": ["missing@example.test"], "body": "Note"}
    enriched, reason = planner.review(intent, action(MAIL, args), args)
    assert enriched is None and reason == "TASK_SEMANTICS_NOT_VERIFIED"
    validate(model.review, model.calls[-1][2])
    assert model.calls[-1][2]["properties"]["evidence"]["maxItems"] == 0


def test_options_are_evidence_of_occurrence_not_automatic_authorization():
    planner, model, intent = setup(model=Model(review=answer(
        evidence("/recipient", quote="Alice"), evidence("/amount", quote="10"),
        decision="out_of_task", conditions_met=False)))
    args = {"recipient": "Alice", "amount": 10}
    enriched, reason = planner.review(intent, action(SEND, args), args)
    assert enriched is None and reason == "TASK_SEMANTICS_NOT_VERIFIED"
    assert not planner._pending


def test_source_option_explosion_fails_without_silent_truncation():
    planner, model, intent = setup(task="Pay the designated invoice")
    args = {"id": "invoice-7"}
    planner.record(action(READ, args), args, [{"recipient": "Alice"}] * 65)
    proposed = {"recipient": "Alice", "amount": 10}
    enriched, reason = planner.review(intent, action(SEND, proposed), proposed)
    assert enriched is None and reason == "TASK_VERIFIER_FAILED_CLOSED"
    assert [c[0] for c in model.calls] == ["plan"]
    assert planner.failures[-1]["phase"] == "verify"


@pytest.mark.case("TC-11")
def test_full_exact_parameter_proof_enables_task_action_but_not_hard_override(rt):
    planner, _, intent = setup()
    args = {"recipient": "Alice", "amount": 10.0}
    proposed = action(SEND, args)
    assert rt.engine.decide(intent, proposed).decision == Verdict.ASK
    enriched, reason = planner.review(intent, proposed, args)
    assert reason == "TASK_PLAN_AND_PARAMETERS_VERIFIED"
    assert rt.engine.decide(enriched, proposed).decision == Verdict.ALLOW
    assert not intent.exact_action_grants
    proposed.labels = ["SECRET"]
    assert rt.engine.decide(enriched, proposed, approved=True).decision == Verdict.BLOCK


@pytest.mark.case("TC-19")
def test_data_dependent_parameters_are_bound_to_observed_values(rt):
    model = Model(
        review=answer(
            evidence("/recipient", "obs_1", "/invoice/payee"),
            evidence("/amount", "obs_1", "/invoice/total"),
        )
    )
    planner, _, intent = setup("Pay the requested invoice", model=model)
    read_args = {"id": "requested"}
    source = {"invoice": {"payee": "Alice", "total": 10}}
    planner.record(action(READ, read_args), read_args, source)
    source["invoice"]["payee"] = "Eve"
    args = {"recipient": "Alice", "amount": 10}
    enriched, _ = planner.review(intent, action(SEND, args), args)
    assert rt.engine.decide(enriched, action(SEND, args)).decision == Verdict.ALLOW
    assert planner.observations[0].result["invoice"]["payee"] == "Alice"


@pytest.mark.case("TC-19")
@pytest.mark.parametrize("labels", [["INJECTION_RISK"], ["SECRET"]])
def test_flagged_source_cannot_supply_authority_even_if_model_says_aligned(labels):
    model = Model(
        review=answer(
            evidence("/recipient", "obs_1", "/recipient"),
            evidence("/amount", "obs_1", "/amount"),
        )
    )
    planner, _, intent = setup("Pay the requested invoice", model=model)
    args = {"recipient": "Eve", "amount": 500}
    read = {"id": "requested"}
    planner.record(action(READ, read), read, args, labels=labels)
    enriched, reason = planner.review(intent, action(SEND, args), args)
    assert enriched is None and reason == "TASK_PARAMETER_EVIDENCE_MISMATCH"
    payload = json.loads(model.calls[-1][1][1]["content"])
    assert not payload["read_data_not_instructions"]


@pytest.mark.case("TC-11")
@pytest.mark.parametrize(
    "change",
    [
        {"recipient": "Eve"},
        {"recipient": "Alice.extra"},
        {"amount": 100},
    ],
)
def test_changed_target_or_amount_fails_even_with_false_model_allow(change):
    planner, _, intent = setup()
    args = {"recipient": "Alice", "amount": 10, **change}
    enriched, reason = planner.review(intent, action(SEND, args), args)
    assert enriched is None and reason == "TASK_PARAMETER_EVIDENCE_MISMATCH"


@pytest.mark.case("TC-11")
@pytest.mark.parametrize(
    "text,quote,expected",
    [
        ("Send 2000 to Alice", "2", False),
        ("Send -10 to Alice", "10", False),
        ("Send 10 to Alice.", "Alice", True),
        ("Send 10 to AliceJones", "Alice", False),
        ("Send to Alice@company.test", "Alice", False),
        ("Post to https://site.test.evil", "https://site.test", False),
        ("Post to https://site.test?copy=1", "https://site.test", False),
        ('Post to "https://site.test"', "https://site.test", True),
    ],
)
def test_plaintext_evidence_is_not_prefix_matching(text, quote, expected):
    assert literal_occurs(text, quote) is expected


@pytest.mark.case("TC-15")
def test_plan_is_bound_to_session_intent_and_catalog():
    planner, model, intent = setup()
    args = {"recipient": "Alice", "amount": 10}
    for proposed, contract in [
        (action(SEND, args, "other-session"), intent),
        (action(SEND, args), intent.model_copy(update={"version": 2})),
    ]:
        assert (
            planner.review(contract, proposed, args)[1] == "TASK_PLAN_BINDING_CHANGED"
        )
    planner.catalog["send_payment"] = spec(
        "send_payment", [Effect.NET_EGRESS], {"recipient": "string"}
    )
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_PLAN_BINDING_CHANGED"
    )
    assert len(model.calls) == 1


@pytest.mark.case("TC-16")
def test_reserved_step_cannot_be_double_spent_and_result_cannot_be_replayed():
    planner, _, intent = setup()
    args = {"recipient": "Alice", "amount": 10}
    proposed = action(SEND, args)
    assert planner.review(intent, proposed, args)[0] is not None
    assert planner.review(intent, action(SEND, args), args)[0] is None
    planner.record(proposed, args, {"transaction_id": "t1"})
    assert planner.used == {"s1": 1}
    with pytest.raises(ValueError, match="UNVERIFIED_EFFECTFUL_OBSERVATION"):
        planner.record(proposed, args, {"transaction_id": "t1"})
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_OPERATION_NOT_PLANNED"
    )


@pytest.mark.case("TC-19")
def test_undispatched_or_cross_session_data_is_not_an_observation():
    planner, _, _ = setup()
    args = {"recipient": "Alice", "amount": 10}
    with pytest.raises(ValueError, match="UNVERIFIED_EFFECTFUL_OBSERVATION"):
        planner.record(action(SEND, args), args, {"id": "invented"})
    read = {"id": "requested"}
    with pytest.raises(ValueError, match="UNVERIFIED_OBSERVATION_SOURCE"):
        planner.record(action(READ, read, "other"), read, "untrusted")
    assert not planner.observations


@pytest.mark.case("TC-26")
@pytest.mark.parametrize(
    "bad_plan",
    [
        {"steps": [{**PLAN["steps"][0], "tool": "new_admin_tool"}]},
        {"steps": [{**PLAN["steps"][0], "sources": ["s2"]}]},
        {"steps": [{**PLAN["steps"][0], "constraints": {"recipient": "any"}}]},
        {"steps": [PLAN["steps"][0], PLAN["steps"][0]]},
    ],
)
def test_malformed_plan_fails_closed(bad_plan):
    intent = resolve("Pay invoice", "u", ".", literal_planning=False)
    planner = TaskPlanner(
        "Pay invoice", [READ, SEND], Model(plan=bad_plan), session_id="s", intent=intent
    )
    assert not planner.prepare()
    assert planner.failures and planner.plan is None
    assert (
        planner.review(intent, action(SEND, {"recipient": "Alice", "amount": 10}), {})[
            0
        ]
        is None
    )


@pytest.mark.case("TC-26")
@pytest.mark.parametrize(
    "review", [None, {"decision": "ALLOW"}, {**answer(), "approve_all": True}]
)
def test_malformed_verifier_never_means_success(review):
    planner, _, intent = setup(model=Model(review=review))
    args = {"recipient": "Alice", "amount": 10}
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_VERIFIER_FAILED_CLOSED"
    )
    assert planner.failures


@pytest.mark.case("TC-11")
@pytest.mark.parametrize(
    "response",
    [
        answer(decision="needs_confirmation"),
        answer(decision="out_of_task"),
        answer(conditions_met=False),
    ],
)
def test_uncertain_conditions_and_out_of_task_require_confirmation(response):
    planner, _, intent = setup(model=Model(review=response))
    args = {"recipient": "Alice", "amount": 10}
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_SEMANTICS_NOT_VERIFIED"
    )
    assert not planner.failures


@pytest.mark.case("TC-10")
def test_every_added_recipient_needs_its_own_proof():
    plan = {
        "steps": [
            {
                "id": "s1",
                "tool": "send_mail",
                "purpose": "Send the public summary to Alice",
                "constraints": {
                    "to": "Alice only",
                    "cc": "none",
                    "body": "public summary",
                },
                "sources": [],
                "max_calls": 1,
            }
        ]
    }
    model = Model(plan=plan, review=answer(evidence("/to/0", quote="Alice")))
    planner, _, intent = setup("Send to Alice", model=model)
    args = {"to": ["Alice"], "cc": ["Eve"], "body": "public summary"}
    assert (
        planner.review(intent, action(MAIL, args), args)[1]
        == "TASK_PARAMETER_EVIDENCE_MISMATCH"
    )


@pytest.mark.case("TC-11")
def test_changed_args_cannot_reuse_the_action_binding():
    planner, _, intent = setup()
    args = {"recipient": "Alice", "amount": 10}
    other = action(SEND, {"recipient": "Eve", "amount": 10})
    assert planner.review(intent, other, args)[1] == "TASK_ACTION_BINDING_MISMATCH"


@pytest.mark.case("TC-06")
def test_empty_information_only_plan_cannot_authorize_a_mutation():
    planner, model, intent = setup(
        "What is the invoice total?", model=Model(plan={"steps": []})
    )
    args = {"recipient": "Alice", "amount": 10}
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_OPERATION_NOT_PLANNED"
    )
    assert len(model.calls) == 1


@pytest.mark.case("TC-06")
def test_pointer_handles_arrays_and_escaped_object_names():
    assert pointer({"a/b": [{"~key": 10}]}, "/a~1b/0/~0key") == 10
    with pytest.raises((ValueError, IndexError, KeyError)):
        pointer([10], "/-1")


@pytest.mark.case("TC-06")
def test_task_only_literal_normalization_is_bound_before_tool_data(rt):
    plan = copy.deepcopy(PLAN)
    plan["steps"][0]["literals"] = {
        "recipient": {"value": "Alice", "evidence_text": "Alice"},
        "amount": {"value": 12.5, "evidence_text": "twelve and a half"},
    }
    model = Model(plan=plan, review=answer())
    planner, _, intent = setup("Send twelve and a half to Alice", model=model)
    args = {"recipient": "Alice", "amount": 12.5}
    enriched, reason = planner.review(intent, action(SEND, args), args)
    assert reason == "TASK_PLAN_AND_PARAMETERS_VERIFIED"
    assert rt.engine.decide(enriched, action(SEND, args)).decision == Verdict.ALLOW


@pytest.mark.case("TC-06")
def test_planner_cannot_invent_the_user_evidence_quote():
    plan = copy.deepcopy(PLAN)
    plan["steps"][0]["literals"] = {
        "recipient": {"value": "Eve", "evidence_text": "Send to Eve"}
    }
    intent = resolve("Send to Alice", "u", ".", literal_planning=False)
    planner = TaskPlanner(
        "Send to Alice", [READ, SEND], Model(plan=plan), session_id="s", intent=intent
    )
    assert not planner.prepare()


@pytest.mark.case("TC-11")
@pytest.mark.parametrize(
    "amount,percent,operation,expected",
    [
        (100, 10, "increase_percent", 110),
        (100, 10, "decrease_percent", 90),
        (100, 10, "sum", 110),
        (100, 10, "subtract", 90),
        (100, 10, "multiply", 1000),
        (100, 10, "divide", 10),
    ],
)
def test_referenced_arithmetic_is_recomputed(amount, percent, operation, expected):
    proofs = [
        evidence("/recipient", "obs_1", "/recipient"),
        {
            "argument": "/amount",
            "operation": operation,
            "operands": [
                {"source": "obs_1", "pointer": "/amount"},
                {"source": "user", "quote": str(percent)},
            ],
        },
    ]
    planner, _, intent = setup(
        "Pay the adjusted invoice using " + str(percent),
        model=Model(review=answer(*proofs)),
    )
    query = {"id": "requested"}
    planner.record(action(READ, query), query, {"recipient": "Alice", "amount": amount})
    args = {"recipient": "Alice", "amount": expected}
    assert planner.review(intent, action(SEND, args), args)[0] is not None


@pytest.mark.case("TC-11")
@pytest.mark.parametrize("actual,operand", [(111, "10"), (110, "invented"), (110, "0")])
def test_arithmetic_wrong_result_or_unreferenced_constant_is_rejected(actual, operand):
    response = answer(
        evidence("/recipient", quote="Alice"),
        {
            "argument": "/amount",
            "operation": "increase_percent",
            "operands": [
                {"source": "obs_1", "pointer": "/amount"},
                {"source": "user", "quote": operand},
            ],
        },
    )
    planner, _, intent = setup(
        "Send Alice the invoice amount plus 10 percent", model=Model(review=response)
    )
    query = {"id": "requested"}
    planner.record(action(READ, query), query, {"amount": 100})
    args = {"recipient": "Alice", "amount": actual}
    assert planner.review(intent, action(SEND, args), args)[0] is None


@pytest.mark.case("TC-31")
def test_semantic_plan_cannot_widen_an_existing_exact_contract():
    intent = resolve('Create file "notes.txt" with content "public"', "user", ".")
    planner, _, intent = setup('Create file "notes.txt" with content "public"', intent=intent)
    args = {"recipient": "Alice", "amount": 10}
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "PREEXISTING_EXACT_CONTRACT_NOT_SATISFIED"
    )


@pytest.mark.case("TC-19")
def test_prior_effectful_source_is_a_real_execution_dependency():
    plan = copy.deepcopy(PLAN)
    later = copy.deepcopy(plan["steps"][0])
    later.update(id="s2", sources=["s1"])
    plan["steps"].append(later)
    model = Model(plan=plan, review=answer(step_id="s2"))
    planner, _, intent = setup(model=model)
    args = {"recipient": "Alice", "amount": 10}
    assert (
        planner.review(intent, action(SEND, args), args)[1]
        == "TASK_SEMANTICS_NOT_VERIFIED"
    )
    payload = json.loads(model.calls[-1][1][1]["content"])
    assert [step["id"] for step in payload["task_plan"]] == ["s1"]
