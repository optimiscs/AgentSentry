"""Task contracts and alignment."""
