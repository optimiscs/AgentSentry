"""Compile a small, closed user-request language into exact tool capabilities.

Only the trusted session task is input. Every clause must be understood; a partial
parse never grants permissions. This is deliberately not a general NLP planner.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Any

from agentsentry.schemas import Effect, ExactActionGrant, digest

# JSON strings provide one unambiguous quoting/escaping convention, including
# semicolons and newlines in file contents. User values are never evaluated.
_LITERAL = r'"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"'
_PREFIX = r"(?:(?:please|(?:can|could|would|will) you(?: please)?)\s+|请(?:帮我)?)?"


@dataclass(frozen=True)
class RequestPattern:
    tool: str
    effect: Effect
    expression: str
    defaults: tuple[tuple[str, str], ...] = ()


def literal(name: str) -> str:
    return "(?P<" + name + ">" + _LITERAL + ")"


# Catalog entries are maintained with the builtin adapters, not learned from tool
# descriptions, observations, attack labels or model-suggested tool names.
PATTERNS = (
    RequestPattern(
        "fs.write",
        Effect.FILE_WRITE,
        r"(?:create|write) file\s+"
        + literal("path")
        + r"\s+with content\s+"
        + literal("content"),
    ),
    RequestPattern(
        "fs.write",
        Effect.FILE_WRITE,
        r"write\s+" + literal("content") + r"\s+to file\s+" + literal("path"),
    ),
    RequestPattern(
        "fs.write",
        Effect.FILE_WRITE,
        r"创建文件\s*"
        + literal("path")
        + r"\s*[，,]?\s*内容为\s*"
        + literal("content"),
    ),
    RequestPattern("exec.python", Effect.EXEC, r"run python\s+" + literal("code")),
    RequestPattern("exec.python", Effect.EXEC, r"执行\s*python\s*" + literal("code")),
    RequestPattern(
        "git.commit", Effect.GIT_COMMIT, r"commit with message\s+" + literal("message")
    ),
    RequestPattern(
        "http.request",
        Effect.NET_EGRESS,
        r"post\s+" + literal("body") + r"\s+to url\s+" + literal("url"),
        (("method", "POST"),),
    ),
)


def canonical_arguments(tool: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Only adapter-defined defaults/case folding; never discard unknown keys."""
    result = dict(arguments)
    if tool == "http.request":
        result.setdefault("method", "POST")
        result.setdefault("body", "")
        if isinstance(result["method"], str):
            result["method"] = result["method"].upper()
    return result


def action_binding(
    server_id: str, tool: str, effects: list[Effect], arguments: dict
) -> str:
    return digest(
        {
            "server": server_id,
            "tool": tool,
            "effects": sorted(e.value for e in effects),
            "arguments": canonical_arguments(tool, arguments),
        }
    )


def _clauses(task: str) -> list[tuple[int, int]] | None:
    # Split only separators outside JSON strings; any malformed quotation fails.
    spans, start, pos = [], 0, 0
    while pos < len(task):
        if task[pos] == '"':
            match = re.match(_LITERAL, task[pos:])
            if match is None:
                return None
            pos += match.end()
        elif task[pos] in ";；\n":
            spans.append((start, pos))
            start = pos + 1
            pos += 1
        else:
            pos += 1
    spans.append((start, len(task)))
    return spans if 1 <= len(spans) <= 16 else None


@dataclass(frozen=True)
class LiteralPlan:
    grants: tuple[ExactActionGrant, ...] = ()
    complete: bool = False


def compile_literal_plan(task: str) -> LiteralPlan | None:
    """Return capabilities only when the entire trusted request parses.

    The grant stores a digest and user evidence offsets, never the literal values.
    Unsupported prose returns None. Once an exact-command introducer is detected,
    a malformed/partial request returns an unresolved plan and stays closed: callers
    must not fall back to broader effect permissions.
    """
    introducer = (
        r'(?:create file\b|write file\b|write\s+"|创建文件|run python\b|'
        r'执行\s*python\b|commit with message\b|post\s+")'
    )
    if not re.match(_PREFIX + introducer, task.strip(), re.I):
        return None
    unresolved = LiteralPlan()
    if len(task) > 8192:
        return unresolved
    spans = _clauses(task)
    if spans is None:
        return unresolved
    grants = []
    for start, end in spans:
        clause = task[start:end].strip()
        for pattern in PATTERNS:
            match = re.fullmatch(
                _PREFIX + pattern.expression + r"\s*[.。]?", clause, re.I
            )
            if match is None:
                continue
            arguments = dict(pattern.defaults)
            for name, value in match.groupdict().items():
                decoded = json.loads(value)
                # Reject unpaired surrogates instead of producing an invalid UTF-8
                # digest or sending invalid text to an adapter.
                try:
                    decoded.encode("utf-8", errors="strict")
                except UnicodeError:
                    return unresolved
                arguments[name] = decoded
            implementations = [("builtin", pattern.tool, arguments)]
            if pattern.tool == "fs.write":
                path = arguments["path"]
                if (
                    not path
                    or path.startswith("/")
                    or ".." in path.split("/")
                    or "\\" in path
                    or "\x00" in path
                    or str(PurePosixPath(path)) != path
                ):
                    return unresolved
                implementations.append(
                    (
                        "native-hook",
                        "native.Write",
                        {
                            "file_path": path,
                            "content": arguments["content"],
                        },
                    )
                )
            for server, tool, params in implementations:
                grants.append(
                    ExactActionGrant(
                        server_id=server,
                        tool=tool,
                        effects=[pattern.effect],
                        binding_hash=action_binding(
                            server, tool, [pattern.effect], params
                        ),
                        evidence_start=start,
                        evidence_end=end,
                    )
                )
            break
        else:
            return unresolved
    return LiteralPlan(tuple(grants), complete=True)
