"""Reviewed AgentDojo tool metadata. No task ids, attack labels, or targets."""

from agentsentry.intent.task_plan import ToolSpec
from pydantic import TypeAdapter

from agentsentry.schemas import Effect

# Reviewed catalog semantics, independent of task/attack labels. Unknown is denied.
READ = set(
    """get_unread_emails get_sent_emails get_received_emails get_draft_emails
search_emails search_contacts_by_name search_contacts_by_email get_current_day
search_calendar_events get_day_calendar_events search_files_by_filename get_file_by_id
list_files search_files get_user_information get_all_hotels_in_city get_hotels_prices
get_rating_reviews_for_hotels get_hotels_address get_all_restaurants_in_city
get_cuisine_type_for_restaurants get_restaurants_address get_rating_reviews_for_restaurants
get_dietary_restrictions_for_all_restaurants get_contact_information_for_restaurants
get_price_for_restaurants check_restaurant_opening_hours get_all_car_rental_companies_in_city
get_car_types_available get_rating_reviews_for_car_rental get_car_fuel_options
get_car_rental_address get_car_price_per_day get_flight_information get_iban get_balance
get_most_recent_transactions get_scheduled_transactions read_file get_user_info
get_channels read_channel_messages read_inbox get_users_in_channel get_webpage""".split()
)
WRITE = set(
    """delete_email create_calendar_event cancel_calendar_event reschedule_calendar_event
add_calendar_event_participants append_to_file create_file delete_file reserve_hotel
reserve_car_rental reserve_restaurant schedule_transaction update_scheduled_transaction
update_password update_user_info add_user_to_channel invite_user_to_slack remove_user_from_slack""".split()
)
EGRESS = set(
    "send_email share_file send_money send_direct_message send_channel_message post_webpage".split()
)


# Only these task-composed text fields are exempt from deterministic authority
# provenance. The semantic verifier still checks every field against the task.
TEXT_FIELDS = {
    "send_email": {"subject", "body"},
    "send_direct_message": {"body"},
    "send_channel_message": {"body"},
    "post_webpage": {"content"},
    "append_to_file": {"content"},
    "create_file": {"content"},
    "create_calendar_event": {"title", "description"},
    "send_money": {"subject"},
    "schedule_transaction": {"subject"},
    "update_scheduled_transaction": {"subject"},
}


def build_catalog(definitions):
    result = []
    for definition in definitions:
        function = definition["function"]
        name, params = function["name"], function["parameters"]
        effect = (
            Effect.FILE_READ
            if name in READ
            else Effect.FILE_WRITE
            if name in WRITE
            else Effect.NET_EGRESS
            if name in EGRESS
            else Effect.OTHER
        )
        if effect == Effect.OTHER:
            # New upstream tools require metadata review, never label-based guesses.
            raise ValueError("UNREVIEWED_AGENTDOJO_TOOL:" + name)
        fields = params.get("properties", {})
        result.append(
            ToolSpec(
                name,
                "agentdojo-simulation",
                (effect,),
                function.get("description", ""),
                params,
                tuple(sorted(set(fields) - TEXT_FIELDS.get(name, set())))
                if effect != Effect.FILE_READ
                else (),
                {
                    key: value["default"]
                    for key, value in fields.items()
                    if "default" in value
                },
            )
        )
    return result


def json_result(value):
    return TypeAdapter(object).dump_python(value, mode="json")
