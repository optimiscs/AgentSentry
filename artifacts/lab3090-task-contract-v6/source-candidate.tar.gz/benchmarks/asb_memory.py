"""Frozen text retrieval for the declared ASB local-embedding adaptation."""

import hashlib
import json
import sqlite3
from contextlib import closing
from pathlib import Path
from types import SimpleNamespace

from asb_native import prepare_instance


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def memory_query(source, task_row, task, attack_row, direct):
    agent = SimpleNamespace()
    prepare_instance(
        agent,
        source,
        task_row,
        task,
        attack_row,
        direct=direct,
        observation=True,
        memory=True,
        model="query-index-only",
    )
    from asb_native import AttackTextTool

    agent.tools.append(AttackTextTool(attack_row).get_tool_call_format())
    if direct:
        agent.task_input += " " + agent.attack_prompts["combined_attack"]
    return agent.task_input + "; " + json.dumps(agent.tools)


def read_documents(database):
    before = sha(database)
    with closing(
        sqlite3.connect(database.resolve().as_uri() + "?mode=ro&immutable=1", uri=True)
    ) as connection:
        connection.execute("PRAGMA query_only=ON")
        rows = connection.execute(
            "SELECT e.embedding_id,m.string_value FROM embeddings e "
            "JOIN embedding_metadata m ON m.id=e.id WHERE m.key='chroma:document' ORDER BY e.embedding_id"
        ).fetchall()
    if sha(database) != before:
        raise ValueError("ASB_SOURCE_MEMORY_CHANGED")
    if len({identifier for identifier, _ in rows}) != len(rows) or not rows:
        raise ValueError("INVALID_ASB_MEMORY_CORPUS")
    return [{"id": identifier, "text": text} for identifier, text in rows]


class FrozenMemory:
    def __init__(self, directory):
        self.directory = Path(directory)
        self.manifest = json.loads((self.directory / "manifest.json").read_text())
        for name, expected in self.manifest["files"].items():
            if sha(self.directory / name) != expected:
                raise ValueError("ASB_RETRIEVAL_ARTIFACT_CHANGED:" + name)
        self.documents = {row["id"]: row["text"] for row in self._rows("corpus.jsonl")}
        self.queries = {
            row["query_sha256"]: row for row in self._rows("retrievals.jsonl")
        }

    def _rows(self, name):
        return [
            json.loads(line)
            for line in (self.directory / name).read_text().splitlines()
        ]

    def similarity_search_with_score(self, query):
        key = hashlib.sha256(query.encode()).hexdigest()
        result = self.queries.get(key)
        if result is None:
            raise ValueError("ASB_QUERY_NOT_IN_FROZEN_RETRIEVAL")
        text = self.documents[result["document_id"]]
        return [(SimpleNamespace(page_content=text), result["cosine_distance"])]
