"""Paired planning diagnostic; original tasks only, no benchmark acceptance claim."""

import argparse
import ast
import hashlib
import json
import time
from pathlib import Path
from types import SimpleNamespace

from agentsentry.intent import task_plan
from agentsentry.intent.contracts import resolve
from asb_native import read_rows, tool_catalog
from asb_pipeline import opaque_spec
from local_model import structured_completion


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default="http://127.0.0.1:18080/v1")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--guard-format", choices=["json_object", "json_schema"], default="json_object")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    artifacts = root.parents[1]
    source = artifacts / "upstream/ASB-1f561dccf92d"
    previous = root.parent / "asb-protocol-v2/src/agentsentry/intent/task_plan.py"
    old_prompt = next(
        ast.literal_eval(node.value)
        for node in ast.parse(previous.read_text()).body
        if isinstance(node, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "PLANNER_PROMPT" for t in node.targets)
    )
    prompts = {"v2": old_prompt, "declared_effects_v3": task_plan.PLANNER_PROMPT}
    args.output.mkdir(parents=True, exist_ok=False)
    config = SimpleNamespace(
        url=args.url, model="Qwen/Qwen3.5-9B", seed=0,
        max_tokens=4096, guard_max_tokens=4096, guard_format=args.guard_format,
    )
    manifest = {
        "status": "PLANNING_DIAGNOSTIC_NOT_ACCEPTANCE",
        "started_at": time.time(), "configuration": vars(config),
        "prompts": prompts,
        "candidate_sha256": hashlib.sha256(Path(task_plan.__file__).read_bytes()).hexdigest(),
        "source": str(source), "task_indices": [0],
        "selection": "first attack catalog per agent, chosen before model calls",
        "limits": "Only original-task planning. No attack context or execution. Development cases, not held-out acceptance.",
    }
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    attacks = read_rows(source / "data/all_attack_tools.jsonl")
    for row in read_rows(source / "data/agent_task.jsonl"):
        attack = next(a for a in attacks if a["Corresponding Agent"] == row["agent_name"])
        _, _, formats, extra = tool_catalog(source, row, attack)
        specs = [opaque_spec(d) for d in formats + [extra]]
        for profile, prompt in prompts.items():
            task_plan.PLANNER_PROMPT = prompt
            records, inputs = [], []

            def model(phase, messages, schema):
                inputs.append({"phase": phase, "messages": messages, "schema": schema})
                return structured_completion(config, phase, messages, schema, records)

            task = row["tasks"][0]
            planner = task_plan.TaskPlanner(
                task, specs, model, session_id="asb-simulation",
                intent=resolve(task, "benchmark-user", ".", literal_planning=False),
            )
            planner.prepare()
            result = {
                "profile": profile, "agent": row["agent_name"], "task": task,
                "plan": planner.plan.model_dump() if planner.plan else None,
                "failures": planner.failures, "inputs": inputs, "records": records,
            }
            with (args.output / "records.jsonl").open("a") as handle:
                handle.write(json.dumps(result, ensure_ascii=False) + "\n")
            print(json.dumps({k: result[k] for k in ["profile", "agent", "plan", "failures"]}), flush=True)
    (args.output / "complete.json").write_text(json.dumps({"finished_at": time.time(), "records": 20}) + "\n")


if __name__ == "__main__":
    main()
