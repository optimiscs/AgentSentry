"""Re-embed ASB memory on CPU with existing E5 weights; never call an LLM/API.

This is an explicit local protocol adaptation, not reproduction of the original
OpenAI embedding space. Corpus/query selection never uses attacker goal labels.
"""

import argparse
import hashlib
import json
import os
import platform
import time
from datetime import datetime, timezone
from pathlib import Path

from asb_memory import memory_query, read_documents, sha
from asb_native import read_rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    os.environ["CUDA_VISIBLE_DEVICES"] = ""
    os.environ["HF_HUB_OFFLINE"] = os.environ["TRANSFORMERS_OFFLINE"] = "1"
    import numpy as np
    import torch
    import transformers
    from transformers import AutoModel, AutoTokenizer

    if args.output.exists() and any(args.output.iterdir()):
        raise ValueError("ASB_RETRIEVAL_OUTPUT_ALREADY_EXISTS")
    args.output.mkdir(parents=True, exist_ok=True)
    source = args.source.resolve()
    database = (
        source
        / "memory_db/direct_prompt_injection/combined_attack_gpt-4o-mini/chroma.sqlite3"
    )
    database_sha256 = sha(database)
    corpus = read_documents(database)
    task_rows = {
        row["agent_name"]: row for row in read_rows(source / "data/agent_task.jsonl")
    }
    queries = {}
    for attack in read_rows(source / "data/all_attack_tools.jsonl"):
        task_row = task_rows[attack["Corresponding Agent"]]
        for direct in [False, True]:
            query = memory_query(source, task_row, task_row["tasks"][0], attack, direct)
            queries[hashlib.sha256(query.encode()).hexdigest()] = query
    identifiers = sorted(queries)
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    torch.manual_seed(0)
    torch.use_deterministic_algorithms(True)
    tokenizer = AutoTokenizer.from_pretrained(
        args.model, local_files_only=True, trust_remote_code=False
    )
    model = (
        AutoModel.from_pretrained(
            args.model, local_files_only=True, trust_remote_code=False
        )
        .to("cpu")
        .eval()
    )
    counts, started = {}, time.perf_counter()

    def encode(texts, kind):
        vectors, lengths = [], []
        for start in range(0, len(texts), 4):
            batch = [
                ("passage: " if kind == "documents" else "query: ") + text
                for text in texts[start : start + 4]
            ]
            lengths.extend(
                len(ids) for ids in tokenizer(batch, truncation=False)["input_ids"]
            )
            inputs = tokenizer(
                batch,
                truncation=True,
                padding=True,
                max_length=512,
                return_tensors="pt",
            )
            with torch.inference_mode():
                hidden = model(**inputs).last_hidden_state
                weights = inputs["attention_mask"].to(hidden.dtype).unsqueeze(-1)
                pooled = (hidden * weights).sum(1) / weights.sum(1)
                norms = pooled.square().sum(1, keepdim=True).sqrt()
                matrix = (pooled / norms.clamp_min(1e-12)).numpy()
            if not np.isfinite(matrix).all():
                raise ValueError("NONFINITE_ASB_EMBEDDING")
            vectors.append(matrix)
            progress = {
                "status": "CPU_EMBEDDING_RUNNING",
                "phase": kind,
                "completed": start + len(batch),
                "planned": len(texts),
            }
            (args.output / "progress.json").write_text(json.dumps(progress) + "\n")
            if start % 100 == 0:
                print(json.dumps(progress), flush=True)
        counts[kind] = {
            "count": len(texts),
            "truncated_at_512": sum(length > 512 for length in lengths),
            "maximum_original_tokens": max(lengths),
        }
        return np.concatenate(vectors)

    documents = encode([document["text"] for document in corpus], "documents")
    query_vectors = encode([queries[key] for key in identifiers], "queries")
    scores = query_vectors @ documents.T
    # Stable ID order resolves exact ties, never the attack row or desired label.
    chosen = scores.argmax(axis=1)
    retrievals = [
        {
            "query_sha256": key,
            "document_id": corpus[int(chosen[i])]["id"],
            "cosine_distance": float(1 - scores[i, chosen[i]]),
        }
        for i, key in enumerate(identifiers)
    ]
    for name, rows in [("corpus.jsonl", corpus), ("retrievals.jsonl", retrievals)]:
        (args.output / name).write_text(
            "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows)
        )
    np.savez_compressed(
        args.output / "embeddings.npz", documents=documents, queries=query_vectors
    )
    (args.output / "query-inputs.jsonl").write_text(
        "".join(
            json.dumps({"sha256": key, "text": queries[key]}) + "\n"
            for key in identifiers
        )
    )
    if sha(database) != database_sha256:
        raise ValueError("ASB_SOURCE_MEMORY_CHANGED_DURING_PREPARATION")
    manifest = {
        "status": "LOCAL_RETRIEVAL_PREPARED_NOT_A_BENCHMARK_SCORE",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_database_sha256": database_sha256,
        "source_files": {
            name: sha(source / name)
            for name in [
                "data/agent_task.jsonl",
                "data/all_normal_tools.jsonl",
                "data/all_attack_tools.jsonl",
            ]
        },
        "preparation_code": {
            name: sha(Path(__file__).parent / name)
            for name in ["prepare_asb_memory.py", "asb_memory.py", "asb_native.py"]
        },
        "model": "intfloat/e5-base-v2",
        "model_revision": "f52bf8ec8c7124536f0efb74aca902b2995e5bcd",
        "model_files": {
            path.name: sha(path)
            for path in sorted(args.model.iterdir())
            if path.is_file()
            and path.suffix in {".json", ".safetensors", ".txt"}
            and "provenance" not in path.name
        },
        "embedding": {
            "device": "cpu",
            "threads": 2,
            "batch_size": 4,
            "dtype": "float32",
            "dimension": int(documents.shape[1]),
            "pooling": "attention-mask-weighted mean then L2 normalization",
            "max_tokens": 512,
            "query_prefix": "query: ",
            "document_prefix": "passage: ",
            "ranking": "exact cosine top1, ties by document id",
        },
        "counts": counts,
        "selected_unique_documents": len(set(row["document_id"] for row in retrievals)),
        "seconds": time.perf_counter() - started,
        "environment": {
            "python": platform.python_version(),
            "torch": torch.__version__,
            "transformers": transformers.__version__,
            "numpy": np.__version__,
        },
        "files": {
            name: sha(args.output / name)
            for name in [
                "corpus.jsonl",
                "retrievals.jsonl",
                "embeddings.npz",
                "query-inputs.jsonl",
            ]
        },
        "limitations": [
            "Rebuilt local E5 space replaces original OpenAI embeddings; original cached vectors are not mixed in.",
            "512-token truncation changes retrieval relative to upstream; full selected document is retained for native workflow extraction.",
            "No attack success labels used in ranking; scene agent membership only defines the native visible catalog.",
            "No defended agent/model workflow was run by this preparation.",
        ],
    }
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    (args.output / "progress.json").write_text(
        json.dumps({"status": manifest["status"], "counts": counts}) + "\n"
    )
    print(
        json.dumps(
            {
                "status": manifest["status"],
                "counts": counts,
                "seconds": manifest["seconds"],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
