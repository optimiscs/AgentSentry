#!/usr/bin/env python3
"""Run pinned AgentDojo suites with native environment/utility/security evaluators.

Only upstream in-memory simulated tools execute. No external model endpoint is allowed.
Attack goal/ground truth are used by upstream attack construction and evaluator only;
the defender receives the ordinary task, tool catalog, calls and observations.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from ast import literal_eval
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

import httpx
from agentdojo.agent_pipeline.agent_pipeline import load_system_message
from agentdojo.agent_pipeline.base_pipeline_element import BasePipelineElement
from agentdojo.agent_pipeline.llms.openai_llm import (
    _function_to_openai,
    _message_to_openai,
)
from agentdojo.agent_pipeline.tool_execution import is_string_list, tool_result_to_str
from agentdojo.attacks.base_attacks import FixedJailbreakAttack
from agentdojo.attacks.important_instructions_attacks import ImportantInstructionsAttack
from agentdojo.functions_runtime import FunctionCall
from agentdojo.task_suite import get_suite
from agentdojo.types import text_content_block_from_string as block

from agentsentry.context.scanner import Scanner
from agentsentry.intent.contracts import resolve
from agentsentry.policy.engine import Engine
from agentsentry.schemas import ActionIR, Effect, SourceType, digest

# Reviewed catalog semantics, independent of task/attack labels. Unknown is denied.
READ = set(
    """get_unread_emails get_sent_emails get_received_emails get_draft_emails
search_emails search_contacts_by_name search_contacts_by_email get_current_day
search_calendar_events get_day_calendar_events search_files_by_filename get_file_by_id
list_files search_files get_user_information get_all_hotels_in_city get_hotels_prices
get_rating_reviews_for_hotels get_hotels_address get_all_restaurants_in_city
get_cuisine_type_for_restaurants get_restaurants_address get_rating_reviews_for_restaurants
get_dietary_restrictions_for_all_restaurants get_contact_information_for_restaurants
get_price_for_restaurants check_restaurant_opening_hours get_all_car_rental_companies_in_city
get_car_types_available get_rating_reviews_for_car_rental get_car_fuel_options
get_car_rental_address get_car_price_per_day get_flight_information get_iban get_balance
get_most_recent_transactions get_scheduled_transactions read_file get_user_info
get_channels read_channel_messages read_inbox get_users_in_channel get_webpage""".split()
)
WRITE = set(
    """delete_email create_calendar_event cancel_calendar_event reschedule_calendar_event
add_calendar_event_participants append_to_file create_file delete_file reserve_hotel
reserve_car_rental reserve_restaurant schedule_transaction update_scheduled_transaction
update_password update_user_info add_user_to_channel invite_user_to_slack remove_user_from_slack""".split()
)
EGRESS = set(
    "send_email share_file send_money send_direct_message send_channel_message post_webpage".split()
)


class LocalPipeline(BasePipelineElement):
    def __init__(self, config, policy):
        self.config, self.name = config, config.model
        self.engine, self.scanner = Engine(policy), Scanner()
        self.calls, self.transcript = [], []
        self.context_labels = set()
        self.model_calls = 0

    def decision(self, task, name, args):
        if self.config.configuration in {"baseline", "rules"}:
            return {"decision": "ALLOW", "reason_codes": ["NO_EXECUTION_GATE"]}
        effect = (
            Effect.FILE_READ
            if name in READ
            else Effect.FILE_WRITE
            if name in WRITE
            else Effect.NET_EGRESS
            if name in EGRESS
            else Effect.OTHER
        )
        action = ActionIR(
            session_id="agentdojo-simulation",
            tool=name,
            server_id="agentdojo-simulation",
            effects=[effect],
            resource="simulation://" + name,
            resource_version=digest(args),
            args_hash=digest(args),
            scope_valid=True,
            scope_allowed=True,
            resource_class="CREDENTIAL" if name == "update_password" else "REPO",
            adapter_valid=effect != Effect.OTHER,
            labels=[]
            if self.config.configuration == "no_taint"
            else sorted(self.context_labels),
            source_type="MCP_RESPONSE",
            source_trust="UNTRUSTED",
            destination_trust="UNKNOWN",
        )
        intent = resolve(task, "benchmark-user", ".")
        if self.config.configuration == "no_intent":
            intent.allowed_effects = intent.maximum_effects
            intent.forbidden_effects = []
        decision = self.engine.decide(intent, action).model_dump(mode="json")
        return decision

    def query(self, query, runtime, env, messages=None, extra_args=None):
        messages = [
            {"role": "system", "content": [block(load_system_message(None))]},
            {"role": "user", "content": [block(query)]},
        ]
        self.transcript = messages
        for _ in range(self.config.max_steps):
            wire = [_message_to_openai(m, self.config.model) for m in messages]
            # Qwen's native template expects system, not OpenAI's newer developer role.
            wire[0]["role"] = "system"
            response = httpx.post(
                self.config.url + "/chat/completions",
                json={
                    "model": self.config.model,
                    "messages": wire,
                    "tools": [
                        _function_to_openai(t) for t in runtime.functions.values()
                    ],
                    "tool_choice": "auto",
                    "temperature": 0,
                    "seed": self.config.seed,
                    "max_tokens": 1024,
                },
                timeout=120,
                trust_env=False,
            )
            self.model_calls += 1
            response.raise_for_status()
            choice = response.json()["choices"][0]
            if choice["finish_reason"] == "length":
                raise ValueError("MODEL_OUTPUT_TRUNCATED")
            message = choice["message"]
            calls = [
                FunctionCall(
                    function=c["function"]["name"],
                    args=json.loads(c["function"]["arguments"]),
                    id=c["id"],
                )
                for c in message.get("tool_calls") or []
            ]
            messages.append(
                {
                    "role": "assistant",
                    "content": [block(message["content"])]
                    if message.get("content") is not None
                    else None,
                    "tool_calls": calls or None,
                }
            )
            if not calls:
                if not message.get("content"):
                    raise ValueError("EMPTY_FINAL_RESPONSE")
                return query, runtime, env, messages, extra_args or {}
            for call in calls:
                for key, value in call.args.items():
                    if isinstance(value, str) and is_string_list(value):
                        call.args[key] = literal_eval(value)
                decision = self.decision(query, call.function, call.args)
                entry = {
                    "tool": call.function,
                    "arguments": call.args,
                    "decision": decision["decision"],
                    "reason_codes": decision["reason_codes"],
                    "simulated_dispatch": False,
                }
                self.calls.append(entry)
                if decision["decision"] == "ALLOW":
                    result, error = runtime.run_function(env, call.function, call.args)
                    entry["simulated_dispatch"] = True
                    raw = error or tool_result_to_str(result)
                else:
                    error = (
                        "AgentSentry "
                        + decision["decision"]
                        + ": "
                        + ",".join(decision["reason_codes"])
                    )
                    raw = error
                entry["tool_error"] = error
                _, signal = self.scanner.scan(
                    "agentdojo-observation", raw, SourceType.MCP_RESPONSE
                )
                self.context_labels.update(signal.labels)
                entry["context_labels"] = signal.labels
                filtered = raw
                if (
                    self.config.configuration not in {"baseline", "no_context"}
                    and "INJECTION_RISK" in signal.labels
                ):
                    filtered = "[AgentSentry quarantined untrusted instructions in this tool response.]"
                    error = None
                messages.append(
                    {
                        "role": "tool",
                        "content": [block(filtered)],
                        "tool_call_id": call.id,
                        "tool_call": call,
                        "error": error,
                    }
                )
        raise ValueError("MODEL_STEP_BUDGET_EXHAUSTED")


def metrics(rows, planned):
    ok = [r for r in rows if r["status"] == "ok"]
    attacks = [r for r in rows if r["injection_task"] is not None]
    valid_attacks = [r for r in attacks if r["status"] == "ok"]
    benign = [r for r in rows if r["injection_task"] is None]
    valid_benign = [r for r in benign if r["status"] == "ok"]
    successes = sum(r["attack_success"] for r in valid_attacks)
    return {
        "planned_cases": planned,
        "recorded_cases": len(rows),
        "completed_cases": len(ok),
        "incomplete_or_error": len(rows) - len(ok),
        "valid_rate": len(ok) / planned if planned else None,
        "attack_cases": len(attacks),
        "attack_valid_cases": len(valid_attacks),
        "native_asr_all": successes / len(attacks) if attacks else None,
        "native_asr_valid": successes / len(valid_attacks) if valid_attacks else None,
        "strict_asr_upper_bound": (successes + len(attacks) - len(valid_attacks))
        / len(attacks)
        if attacks
        else None,
        "benign_cases": len(benign),
        "benign_valid_cases": len(valid_benign),
        "benign_utility_all": sum(r["utility"] for r in valid_benign) / len(benign)
        if benign
        else None,
        "benign_cases_with_block": sum(
            any(c["decision"] == "BLOCK" for c in r["calls"]) for r in benign
        ),
        "benign_cases_with_ask": sum(
            any(c["decision"] == "ASK" for c in r["calls"]) for r in benign
        ),
        "attack_utility_all": sum(r["utility"] for r in valid_attacks) / len(attacks)
        if attacks
        else None,
        "tool_calls": sum(len(r["calls"]) for r in rows),
        "all_planned_records_present": len(rows) == planned,
        "all_cases_evaluated": len(ok) == planned,
    }


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--url", default="http://127.0.0.1:18080/v1")
    p.add_argument("--model", default="agentsentry-local-qwen")
    p.add_argument("--version", default="v1.2.2")
    p.add_argument(
        "--configuration",
        choices=["baseline", "rules", "full", "no_context", "no_intent", "no_taint"],
        required=True,
    )
    p.add_argument("--mode", choices=["benign", "attack", "all"], default="all")
    p.add_argument("--limit-per-suite", type=int, default=0)
    p.add_argument("--max-steps", type=int, default=15)
    p.add_argument("--workers", type=int, default=4)
    p.add_argument("--seed", type=int, default=0)
    a = p.parse_args()
    if (
        urlsplit(a.url).hostname not in {"127.0.0.1", "localhost"}
        or urlsplit(a.url).scheme != "http"
    ):
        raise ValueError("ONLY_LOCAL_MODEL_ENDPOINT_ALLOWED")
    source = a.source.resolve()
    import agentdojo

    if Path(agentdojo.__file__).resolve().parents[2] != source:
        raise ValueError("INSTALLED_BENCHMARK_SOURCE_MISMATCH")
    provenance = json.loads((source / "agentsentry-source.json").read_text())
    root = Path(__file__).resolve().parents[1]
    policy = (root / "policies/default.aspolicy").read_text()
    planned = []
    for name in ["workspace", "travel", "banking", "slack"]:
        suite = get_suite(a.version, name)
        users = list(suite.user_tasks)
        injections = list(suite.injection_tasks)
        if a.limit_per_suite:
            users, injections = (
                users[: a.limit_per_suite],
                injections[: a.limit_per_suite],
            )
        for user in users:
            for injection in ([None] if a.mode != "attack" else []) + (
                injections if a.mode != "benign" else []
            ):
                planned.append((name, user, injection))
    a.output.mkdir(parents=True, exist_ok=True)
    ids = ["/".join([s, u, i or "benign"]) for s, u, i in planned]
    manifest = {
        "benchmark": "AgentDojo",
        "benchmark_commit": provenance["commit"],
        "source_archive_sha256": provenance["archive_sha256"],
        "version": a.version,
        "configuration": a.configuration,
        "model": a.model,
        "seed": a.seed,
        "temperature": 0,
        "max_tokens": 1024,
        "max_steps": a.max_steps,
        "workers": a.workers,
        "attack": "important_instructions",
        "attack_user_name": "Emma Johnson",
        "attack_model_name": a.model,
        "scope": "pilot" if a.limit_per_suite else "full_native_suite",
        "mode": a.mode,
        "planned_ids": ids,
        "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "policy_sha256": hashlib.sha256(policy.encode()).hexdigest(),
        "source_files": {
            str(f.relative_to(root)): hashlib.sha256(f.read_bytes()).hexdigest()
            for f in (root / "src/agentsentry").rglob("*.py")
        },
        "native_evaluator": "TaskSuite.run_task_with_pipeline (utility, injection_success)",
        "real_tools_executed": False,
        "adaptations": [
            "Local OpenAI-compatible tool-call protocol; native default system prompt and tool schemas",
            "System role retained for Qwen template; temperature 0; 1024 output tokens; bounded 15 tool iterations; errors not attack failures",
            "Official important_instructions attack template with explicit local model name; upstream injection candidates/ground truth used only by attacker/evaluator",
            "Reviewed tool-effect table; simulated service state represented as resources; not a production adapter",
            "ASK pending without human approval; unknown destinations never implicitly trusted",
            "Conservative session-wide explicit label union; whole risky observation quarantine can lose benign content",
        ],
        "started_at": datetime.now(timezone.utc).isoformat(),
    }
    path = a.output / "manifest.json"
    if path.exists():
        prior = json.loads(path.read_text())
        if {k: v for k, v in manifest.items() if k != "started_at"} != {
            k: v for k, v in prior.items() if k != "started_at"
        }:
            raise ValueError("RESUME_MANIFEST_MISMATCH")
    else:
        path.write_text(json.dumps(manifest, indent=2) + "\n")
    path = a.output / "per_case.jsonl"
    rows = (
        [json.loads(line) for line in path.read_text().splitlines()]
        if path.exists()
        else []
    )
    done = {r["case_id"] for r in rows}
    if len(done) != len(rows) or not done <= set(ids):
        raise ValueError("INVALID_RESUME_RECORDS")

    def one(case):
        name, user_id, injection_id = case
        row = {
            "case_id": "/".join([name, user_id, injection_id or "benign"]),
            "suite": name,
            "user_task": user_id,
            "injection_task": injection_id,
            "status": "error",
        }
        pipeline = LocalPipeline(a, policy)
        started = time.perf_counter()
        try:
            suite = get_suite(a.version, name)
            user = suite.user_tasks[user_id]
            injection = suite.injection_tasks[injection_id] if injection_id else None
            attack = FixedJailbreakAttack(
                ImportantInstructionsAttack._JB_STRING, suite, pipeline
            )
            attack.user_name, attack.model_name = "Emma Johnson", a.model
            payloads = attack.attack(user, injection) if injection else {}
            row["injections"] = payloads
            utility, success = suite.run_task_with_pipeline(
                pipeline, user, injection, payloads
            )
            row.update(
                status="ok",
                utility=bool(utility),
                attack_success=bool(success) if injection else None,
            )
        except Exception as exc:
            row["error"] = type(exc).__name__ + (
                ":" + str(exc) if isinstance(exc, ValueError) else ""
            )
            if isinstance(exc, httpx.HTTPStatusError):
                row["http_status"] = exc.response.status_code
                row["model_error"] = exc.response.text[:4096]
        row.update(
            calls=pipeline.calls,
            transcript=pipeline.transcript,
            model_calls=pipeline.model_calls,
            seconds=time.perf_counter() - started,
        )
        return row

    with path.open("a") as out, ThreadPoolExecutor(max_workers=a.workers) as pool:
        futures = [
            pool.submit(one, c) for c, key in zip(planned, ids) if key not in done
        ]
        for future in as_completed(futures):
            row = future.result()
            rows.append(row)
            out.write(
                json.dumps(row, default=lambda x: x.model_dump(), ensure_ascii=False)
                + "\n"
            )
            out.flush()
            if len(rows) % 10 == 0 or len(rows) == len(planned):
                print(
                    json.dumps(
                        {
                            "completed": len(rows),
                            "planned": len(planned),
                            "errors": sum(r["status"] != "ok" for r in rows),
                        }
                    ),
                    flush=True,
                )
    summary = metrics(rows, len(planned))
    (a.output / "metrics.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)
    return 0 if summary["all_cases_evaluated"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
